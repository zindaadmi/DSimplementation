DATA STRUCTURES IN PHP
---

# Implementations 
## SingleLinkedlist
### Elements:
#### Head
#### Data
#### next
#### Null

### Operations
-Insertion
-Deletion
-Traversal/Printing
###Insertion:
#### Inserting an element at the beginning of the list
#### Inserting An element at the end of the list
#### Inserting an element anywhere in the list
 
### Deletion:
#### Deleting an element at the beginning of the list
#### Deleting an element at the end of the list
#### Deleting an element anywhere in the list

### Printing:
#### Printing the Linked list 

### Syntax: php index.php